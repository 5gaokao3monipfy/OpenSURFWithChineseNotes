版权声明：本资源为CSDN博主「UESTC 五高考3模拟」的原创资源，遵循CC 4.0 BY-SA版权协议，转载请附上资源出处及本声明。

使用说明：
在example2和example3中输入目标图像的文件索引号即可使用
需要在matlab浏览文件夹选项中，选择OpenSURFWithChineseNote文件夹方可正常运行


